﻿最简单的基于FFmpeg的图像编码器
Simplest FFmpeg Picture Encoder

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020


本程序实现了YUV420P像素数据编码为JPEG图片。是最简单的FFmpeg编码方面的教程。
通过学习本例子可以了解FFmpeg的编码流程。


This software encode YUV420P data to JPEG files.
It the simplest picture encoder based on FFmpeg.