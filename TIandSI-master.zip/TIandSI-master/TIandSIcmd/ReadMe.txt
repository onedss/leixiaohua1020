﻿TIandSIcmd

王彩虹，雷霄骅，张晖
nonmarking2010@gmail.com
中国传媒大学/数字电视技术

输入YUV文件路径，分辨率，像素格式
输出TI,SI值
