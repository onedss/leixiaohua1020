﻿最简单的基于FFmpeg的AVFilter例子（叠加水印）
Simplest FFmpeg AVfilter Example (Watermark)

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020


本程序使用FFmpeg的AVfilter实现了视频的水印叠加功能。
可以将一张PNG图片作为水印叠加到视频上。
是最简单的FFmpeg的AVFilter方面的教程。
适合FFmpeg的初学者。


This software uses FFmpeg's AVFilter to add watermark in a video file.
It can add a PNG format picture as watermark to a video file.
It's the simplest example based on FFmpeg's AVFilter. 
Suitable for beginner of FFmpeg 