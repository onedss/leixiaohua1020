﻿最简单的OpenGL播放视频的例子（OpenGL播放RGB/YUV）
Simplest Video Play OpenGL (OpenGL play RGB/YUV) 

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020

本程序使用OpenGL播放RGB/YUV视频像素数据。
是最简单的OpenGL播放视频的教程。

This software plays RGB/YUV raw video data using OpenGL.
It's the simplest OpenGL tutorial (About video playback).