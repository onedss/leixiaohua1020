﻿最简单的基于FFmpeg的收流器（接收RTMP）
Simplest FFmpeg Receiver (Receive RTMP)

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020


本例子将流媒体数据（以RTMP为例）保存成本地文件。
是使用FFmpeg进行流媒体接收最简单的教程。


This example saves streaming media data (Use RTMP as example)
as a local file.
It's the simplest FFmpeg stream receiver.