﻿最简单的基于FFmpeg的Swscale示例
Simplest FFmpeg Swscale

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020


本程序使用libswscale对像素数据进行缩放转换等处理。
是最简单的libswscale的教程。


This software uses libswscale to scale / convert pixels.
It the simplest tutorial about libswscale.