﻿最简单的测试图片生成工具
Simplest Pic Gen

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020


本程序可以生成多种RGB/YUV格式的测试图像。包括：
灰阶图        [YUV420P]
彩条图        [RGB24]
彩色条纹图    [RGB24]
RGB渐变彩条图 [RGB24]
YUV渐变彩条图 [YUV420P]
颜色视频      [RGB24][YUV444P]


This software can generate several test pictures:
Gray Bar Picture         [YUV420P]
Color Bar Picture        [RGB24]
Color Stripe Picture     [RGB24]
RGB Gradient Bar Picture [RGB24]
YUV Gradient Bar Picture [YUV420P]
All Color Video          [RGB24][YUV444P]