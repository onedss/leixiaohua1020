#! /bin/sh
g++ simplest_pic_gen.c -g -o simplest_pic_gen.out
