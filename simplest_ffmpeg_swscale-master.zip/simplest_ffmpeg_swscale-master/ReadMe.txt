﻿最简单的基于FFmpeg的libswscale的示例
Simplest FFmpeg swscale

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020


本程序是最简单的基于FFmpeg的libswscale进行像素处理的示例。它包含了两个工程：
simplest_ffmpeg_swscale: 最简单的libswscale的教程。
simplest_pic_gen: 生成各种测试图片的工具。


This software is the simplest tutorial about handle pixel data using libswscale in FFmpeg. 
It contains 2 projects:
simplest_ffmpeg_swscale: the simplest tutorial about libswscale.
simplest_pic_gen: Tools that generate several test pictures.
