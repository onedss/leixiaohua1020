int decode_audio(char* filename);
int decode_video(char* filename);
