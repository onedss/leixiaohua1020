﻿最简单的视频关键帧提取器
Simplest Keyframe Extractor

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020

本程序实现了视频数据中关键帧的提取。
This software extract keyframe from input video data.