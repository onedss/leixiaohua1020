﻿最简单的基于FFmpeg的视音频分离器
Simplest FFmpeg Demuxer

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020


本程序可以将封装格式中的视频码流数据和音频码流数据分离出来。
在该例子中， 将MPEG2TS的文件分离得到H.264视频码流文件和AAC
音频码流文件。


This software split a media file (in Container such as 
MKV, FLV, AVI...) to video and audio bitstream.
In this example, it demux a MPEG2TS file to H.264 bitstream
and AAC bitstream.
