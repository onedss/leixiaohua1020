﻿最简单的基于FFmpeg的封装格式转换器
Simplest FFmpeg Remuxer

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020


本程序实现了视频封装格式之间的转换。
需要注意的是本程序并不改变视音频的编码格式。


This software converts a media file from one container format
to another container format without encoding/decoding video files.