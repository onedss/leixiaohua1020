﻿最简单的基于FFmpeg的音频播放器 2 (SDL 2.0)
Simplest FFmpeg Audio Player 2 (SDL 2.0)

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020

本程序实现了音频的解码和播放。

This software decode and play audio streams.

