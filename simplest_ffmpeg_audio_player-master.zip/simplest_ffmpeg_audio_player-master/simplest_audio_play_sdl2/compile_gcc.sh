#! /bin/sh
gcc simplest_audio_play_sdl2.cpp -g -o simplest_audio_play_sdl2.out -I /usr/local/include -L /usr/local/lib -lSDL2main -lSDL2