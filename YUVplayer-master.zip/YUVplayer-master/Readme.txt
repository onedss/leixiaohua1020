raw-yuvplayer Modified by Lei Xiaohua

http://blog.csdn.net/leixiaohua1020

Original Project Link:
https://sourceforge.net/projects/raw-yuvplayer/

Add following functions:
(1) Fix 2 memory leaks.
(2) Add RGB file type in Open File Dialog
(3) Automatic parse raw video's width and height 
    from file name. Format is like "XXX_{width}x{height}.yuv"
(4) Add Chinese language support
(5) Add 8:1 Zomm in.